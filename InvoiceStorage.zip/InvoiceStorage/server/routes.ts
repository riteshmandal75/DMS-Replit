import type { Express } from "express";
import { createServer, type Server } from "http";
import { Router } from "express";
import { storage } from "./storage";
import { isAuthenticated } from "./replitAuth";
import { insertDocumentSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs/promises";
import { randomUUID } from "crypto";

// Configure multer for file uploads
const upload = multer({
  dest: "uploads/",
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ["application/pdf", "image/jpeg", "image/png", "image/tiff"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Invalid file type. Only PDF and image files are allowed."));
    }
  },
});

// Ensure uploads directory exists
fs.mkdir("uploads", { recursive: true }).catch(console.error);

export async function registerRoutes(app: Express): Promise<Server> {
  const router = Router();

  // Health check
  router.get("/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Auth endpoints
  router.get("/auth/user", (req, res) => {
    if (req.isAuthenticated()) {
      const user = req.user as any;
      const claims = user.claims;
      res.json({
        user: {
          id: claims?.sub,
          email: claims?.email,
          firstName: claims?.first_name,
          lastName: claims?.last_name,
          profileImageUrl: claims?.profile_image_url,
        },
      });
    } else {
      res.status(401).json({ error: "Not authenticated" });
    }
  });

  // Document upload endpoint
  router.post("/documents/upload", isAuthenticated, upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const user = req.user as any;
      const userId = user.claims?.sub;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      // Parse metadata from request body
      const metadata = {
        vendorName: req.body.vendorName,
        invoiceNumber: req.body.invoiceNumber,
        invoiceDate: new Date(req.body.invoiceDate),
        amount: req.body.amount ? req.body.amount.toString() : undefined,
        category: req.body.category,
        description: req.body.description,
      };

      // Generate filename using naming convention with UUID to prevent collisions: Vendor_Name_Invoice_Number_UUID
      const sanitizeFilename = (str: string) => str.replace(/[^a-zA-Z0-9]/g, "_");
      const fileExtension = path.extname(req.file.originalname);
      const uniqueId = randomUUID().substring(0, 8); // Use first 8 characters of UUID for shorter filenames
      const generatedFileName = `${sanitizeFilename(metadata.vendorName)}_${sanitizeFilename(metadata.invoiceNumber)}_${uniqueId}${fileExtension}`;

      // Move file to permanent location
      const permanentPath = path.join("uploads", generatedFileName);
      await fs.rename(req.file.path, permanentPath);

      // Create document record
      const document = await storage.createDocument({
        fileName: generatedFileName,
        originalFileName: req.file.originalname,
        filePath: permanentPath,
        fileSize: req.file.size.toString(),
        fileType: req.file.mimetype,
        uploadedBy: userId,
        ...metadata,
      });

      res.json({ document });
    } catch (error) {
      console.error("File upload error:", error);
      res.status(500).json({ error: "File upload failed" });
    }
  });

  // Get documents with filtering - filtered by user access
  router.get("/documents", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims?.sub;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      const filters = {
        // Admin users can see all documents, regular users only see their own
        uploadedBy: await storage.isUserAdmin(userId) ? undefined : userId,
        vendorName: req.query.vendorName as string,
        category: req.query.category as string,
        dateFrom: req.query.dateFrom ? new Date(req.query.dateFrom as string) : undefined,
        dateTo: req.query.dateTo ? new Date(req.query.dateTo as string) : undefined,
        searchTerm: req.query.searchTerm as string,
        sortBy: req.query.sortBy as 'createdAt' | 'invoiceDate' | 'vendorName' || 'createdAt',
        sortOrder: req.query.sortOrder as 'asc' | 'desc' || 'desc',
        limit: req.query.limit ? parseInt(req.query.limit as string) : undefined,
        offset: req.query.offset ? parseInt(req.query.offset as string) : undefined,
      };

      const result = await storage.getDocuments(filters);
      res.json(result);
    } catch (error) {
      console.error("Get documents error:", error);
      res.status(500).json({ error: "Failed to fetch documents" });
    }
  });

  // Get single document - with authorization check
  router.get("/documents/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims?.sub;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }

      // Check if user has view access using the comprehensive authorization helper
      const hasAccess = await storage.canUserAccessDocument(req.params.id, userId, 'view');
      if (!hasAccess) {
        return res.status(403).json({ error: "Access denied to this document" });
      }

      res.json({ document });
    } catch (error) {
      console.error("Get document error:", error);
      res.status(500).json({ error: "Failed to fetch document" });
    }
  });

  // Update document - with authorization check
  router.patch("/documents/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims?.sub;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      // Check if document exists
      const existingDocument = await storage.getDocument(req.params.id);
      if (!existingDocument) {
        return res.status(404).json({ error: "Document not found" });
      }

      // Check if user has edit access using the comprehensive authorization helper
      const hasAccess = await storage.canUserAccessDocument(req.params.id, userId, 'edit');
      if (!hasAccess) {
        return res.status(403).json({ error: "Access denied - insufficient permissions" });
      }

      const updates = {
        vendorName: req.body.vendorName,
        invoiceNumber: req.body.invoiceNumber,
        invoiceDate: req.body.invoiceDate ? new Date(req.body.invoiceDate) : undefined,
        amount: req.body.amount ? req.body.amount.toString() : undefined,
        category: req.body.category,
        description: req.body.description,
      };

      // Remove undefined values
      Object.keys(updates).forEach(key => {
        if (updates[key as keyof typeof updates] === undefined) {
          delete updates[key as keyof typeof updates];
        }
      });

      const document = await storage.updateDocument(req.params.id, updates);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }
      res.json({ document });
    } catch (error) {
      console.error("Update document error:", error);
      res.status(500).json({ error: "Failed to update document" });
    }
  });

  // Delete document - with authorization check
  router.delete("/documents/:id", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims?.sub;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      // Check if document exists
      const existingDocument = await storage.getDocument(req.params.id);
      if (!existingDocument) {
        return res.status(404).json({ error: "Document not found" });
      }

      // Check if user has delete access using the comprehensive authorization helper
      const hasAccess = await storage.canUserAccessDocument(req.params.id, userId, 'delete');
      if (!hasAccess) {
        return res.status(403).json({ error: "Access denied - insufficient permissions" });
      }

      const success = await storage.deleteDocument(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Document not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Delete document error:", error);
      res.status(500).json({ error: "Failed to delete document" });
    }
  });

  // Download document file - with authorization check
  router.get("/documents/:id/download", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims?.sub;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }

      // Check if user has view access using the comprehensive authorization helper
      const hasAccess = await storage.canUserAccessDocument(req.params.id, userId, 'view');
      if (!hasAccess) {
        return res.status(403).json({ error: "Access denied to download this document" });
      }

      res.download(document.filePath, document.originalFileName);
    } catch (error) {
      console.error("Download document error:", error);
      res.status(500).json({ error: "Failed to download document" });
    }
  });

  // Get document statistics/analytics - filtered by user access
  router.get("/analytics/stats", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims?.sub;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      const filters = {
        // Admin users can see stats for all documents, regular users only see their own
        uploadedBy: await storage.isUserAdmin(userId) ? undefined : userId,
        dateFrom: req.query.dateFrom ? new Date(req.query.dateFrom as string) : undefined,
        dateTo: req.query.dateTo ? new Date(req.query.dateTo as string) : undefined,
      };

      const stats = await storage.getDocumentStats(filters);
      res.json(stats);
    } catch (error) {
      console.error("Get stats error:", error);
      res.status(500).json({ error: "Failed to fetch statistics" });
    }
  });

  // Export endpoints for reports
  router.get("/reports/export/csv", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims?.sub;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      const filters = {
        uploadedBy: await storage.isUserAdmin(userId) ? undefined : userId,
        dateFrom: req.query.dateFrom ? new Date(req.query.dateFrom as string) : undefined,
        dateTo: req.query.dateTo ? new Date(req.query.dateTo as string) : undefined,
        vendorName: req.query.vendorName !== 'all' ? req.query.vendorName as string : undefined,
        category: req.query.category !== 'all' ? req.query.category as string : undefined,
        limit: 1000, // Export limit
        offset: 0
      };

      const { documents } = await storage.getDocuments(filters);
      
      // Generate CSV content
      const csvHeader = 'Date,Vendor,Invoice Number,Amount,Category,Description,Uploaded At\n';
      const csvRows = documents.map(doc => {
        const date = doc.invoiceDate ? new Date(doc.invoiceDate).toISOString().split('T')[0] : '';
        const uploadedAt = doc.createdAt ? new Date(doc.createdAt).toISOString().split('T')[0] : '';
        const amount = doc.amount || '0';
        const vendor = (doc.vendorName || '').replace(/,/g, ';');
        const invoice = (doc.invoiceNumber || '').replace(/,/g, ';');
        const category = (doc.category || '').replace(/,/g, ';');
        const description = (doc.description || '').replace(/,/g, ';');
        return `${date},${vendor},${invoice},${amount},${category},${description},${uploadedAt}`;
      }).join('\n');
      
      const csvContent = csvHeader + csvRows;
      
      // Set headers for file download
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="documents-export-${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csvContent);
    } catch (error) {
      console.error("CSV export error:", error);
      res.status(500).json({ error: "Failed to export CSV" });
    }
  });

  router.get("/reports/export/excel", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims?.sub;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      // For now, Excel export will return CSV format
      // In a production app, you'd use a library like 'exceljs' to create actual Excel files
      const filters = {
        uploadedBy: await storage.isUserAdmin(userId) ? undefined : userId,
        dateFrom: req.query.dateFrom ? new Date(req.query.dateFrom as string) : undefined,
        dateTo: req.query.dateTo ? new Date(req.query.dateTo as string) : undefined,
        vendorName: req.query.vendorName !== 'all' ? req.query.vendorName as string : undefined,
        category: req.query.category !== 'all' ? req.query.category as string : undefined,
        limit: 1000,
        offset: 0
      };

      const { documents } = await storage.getDocuments(filters);
      
      // Generate CSV content (Excel can open CSV files)
      const csvHeader = 'Date,Vendor,Invoice Number,Amount,Category,Description,Uploaded At\n';
      const csvRows = documents.map(doc => {
        const date = doc.invoiceDate ? new Date(doc.invoiceDate).toISOString().split('T')[0] : '';
        const uploadedAt = doc.createdAt ? new Date(doc.createdAt).toISOString().split('T')[0] : '';
        const amount = doc.amount || '0';
        const vendor = (doc.vendorName || '').replace(/,/g, ';');
        const invoice = (doc.invoiceNumber || '').replace(/,/g, ';');
        const category = (doc.category || '').replace(/,/g, ';');
        const description = (doc.description || '').replace(/,/g, ';');
        return `${date},${vendor},${invoice},${amount},${category},${description},${uploadedAt}`;
      }).join('\n');
      
      const csvContent = csvHeader + csvRows;
      
      // Set headers for Excel-compatible download
      res.setHeader('Content-Type', 'application/vnd.ms-excel');
      res.setHeader('Content-Disposition', `attachment; filename="documents-export-${new Date().toISOString().split('T')[0]}.xls"`);
      res.send(csvContent);
    } catch (error) {
      console.error("Excel export error:", error);
      res.status(500).json({ error: "Failed to export Excel" });
    }
  });

  // Permission management endpoints
  // Grant permission to user for a document
  router.post("/documents/:id/permissions", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims?.sub;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      const { targetUserId, permission } = req.body;

      if (!targetUserId || !permission) {
        return res.status(400).json({ error: "Target user ID and permission level are required" });
      }

      if (!['view', 'edit', 'delete'].includes(permission)) {
        return res.status(400).json({ error: "Invalid permission level. Must be view, edit, or delete" });
      }

      // Check if document exists
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }

      // Only document owner or admin can grant permissions
      if (document.uploadedBy !== userId && !(await storage.isUserAdmin(userId))) {
        return res.status(403).json({ error: "Only document owner or admin can grant permissions" });
      }

      // Check if target user exists
      const targetUser = await storage.getUser(targetUserId);
      if (!targetUser) {
        return res.status(404).json({ error: "Target user not found" });
      }

      const newPermission = await storage.addDocumentPermission(req.params.id, targetUserId, permission);
      res.json({ permission: newPermission });
    } catch (error) {
      console.error("Grant permission error:", error);
      res.status(500).json({ error: "Failed to grant permission" });
    }
  });

  // Revoke permission from user for a document
  router.delete("/documents/:id/permissions/:targetUserId", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims?.sub;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      // Check if document exists
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }

      // Only document owner or admin can revoke permissions
      if (document.uploadedBy !== userId && !(await storage.isUserAdmin(userId))) {
        return res.status(403).json({ error: "Only document owner or admin can revoke permissions" });
      }

      const success = await storage.removeDocumentPermission(req.params.id, req.params.targetUserId);
      if (!success) {
        return res.status(404).json({ error: "Permission not found" });
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Revoke permission error:", error);
      res.status(500).json({ error: "Failed to revoke permission" });
    }
  });

  // List permissions for a document
  router.get("/documents/:id/permissions", isAuthenticated, async (req, res) => {
    try {
      const user = req.user as any;
      const userId = user.claims?.sub;

      if (!userId) {
        return res.status(401).json({ error: "User not authenticated" });
      }

      // Check if document exists
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ error: "Document not found" });
      }

      // Only document owner or admin can view permissions
      if (document.uploadedBy !== userId && !(await storage.isUserAdmin(userId))) {
        return res.status(403).json({ error: "Only document owner or admin can view permissions" });
      }

      const permissions = await storage.getDocumentPermissions(req.params.id);
      res.json({ permissions });
    } catch (error) {
      console.error("Get permissions error:", error);
      res.status(500).json({ error: "Failed to fetch permissions" });
    }
  });

  // Mount all routes under /api prefix
  app.use("/api", router);

  const httpServer = createServer(app);
  return httpServer;
}