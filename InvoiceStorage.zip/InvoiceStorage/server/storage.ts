import {
  users,
  documents,
  documentPermissions,
  type User,
  type UpsertUser,
  type Document,
  type InsertDocument,
  type DocumentPermission,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, like, sql, between } from "drizzle-orm";
import { randomUUID } from "crypto";

// Interface for storage operations
export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Document operations
  createDocument(documentData: Omit<typeof documents.$inferInsert, 'id' | 'createdAt' | 'updatedAt'>): Promise<Document>;
  getDocument(id: string): Promise<Document | undefined>;
  getDocuments(filters: {
    uploadedBy?: string;
    vendorName?: string;
    category?: string;
    dateFrom?: Date;
    dateTo?: Date;
    searchTerm?: string;
    sortBy?: 'createdAt' | 'invoiceDate' | 'vendorName';
    sortOrder?: 'asc' | 'desc';
    limit?: number;
    offset?: number;
  }): Promise<{ documents: Document[]; total: number }>;
  updateDocument(id: string, updates: Partial<Omit<typeof documents.$inferInsert, 'id' | 'createdAt'>>): Promise<Document | undefined>;
  deleteDocument(id: string): Promise<boolean>;
  
  // Permission operations
  addDocumentPermission(documentId: string, userId: string, permission: string): Promise<DocumentPermission>;
  getUserDocumentPermission(documentId: string, userId: string): Promise<DocumentPermission | undefined>;
  removeDocumentPermission(documentId: string, userId: string): Promise<boolean>;
  getDocumentPermissions(documentId: string): Promise<DocumentPermission[]>;
  
  // Authorization helper methods
  canUserAccessDocument(documentId: string, userId: string, requiredPermission: 'view' | 'edit' | 'delete'): Promise<boolean>;
  isUserAdmin(userId: string): Promise<boolean>;
  
  // Analytics operations
  getDocumentStats(filters: {
    uploadedBy?: string;
    dateFrom?: Date;
    dateTo?: Date;
  }): Promise<{
    totalDocuments: number;
    totalAmount: number;
    uniqueVendors: number;
    documentsByCategory: Array<{ category: string; count: number; amount: number }>;
    topVendors: Array<{ vendor: string; count: number; amount: number }>;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations - mandatory for Replit Auth
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Document operations
  async createDocument(documentData: Omit<typeof documents.$inferInsert, 'id' | 'createdAt' | 'updatedAt'>): Promise<Document> {
    const [document] = await db
      .insert(documents)
      .values({
        ...documentData,
        id: randomUUID(),
        createdAt: new Date(),
        updatedAt: new Date(),
      })
      .returning();
    return document;
  }

  async getDocument(id: string): Promise<Document | undefined> {
    const [document] = await db
      .select()
      .from(documents)
      .where(and(eq(documents.id, id), eq(documents.isDeleted, false)));
    return document;
  }

  async getDocuments(filters: {
    uploadedBy?: string;
    vendorName?: string;
    category?: string;
    dateFrom?: Date;
    dateTo?: Date;
    searchTerm?: string;
    sortBy?: 'createdAt' | 'invoiceDate' | 'vendorName';
    sortOrder?: 'asc' | 'desc';
    limit?: number;
    offset?: number;
  }): Promise<{ documents: Document[]; total: number }> {
    const conditions = [eq(documents.isDeleted, false)];
    
    if (filters.uploadedBy) {
      conditions.push(eq(documents.uploadedBy, filters.uploadedBy));
    }
    
    if (filters.vendorName) {
      conditions.push(eq(documents.vendorName, filters.vendorName));
    }
    
    if (filters.category) {
      conditions.push(eq(documents.category, filters.category));
    }
    
    if (filters.dateFrom && filters.dateTo) {
      conditions.push(between(documents.invoiceDate, filters.dateFrom, filters.dateTo));
    } else if (filters.dateFrom) {
      conditions.push(sql`${documents.invoiceDate} >= ${filters.dateFrom}`);
    } else if (filters.dateTo) {
      conditions.push(sql`${documents.invoiceDate} <= ${filters.dateTo}`);
    }
    
    if (filters.searchTerm) {
      const searchPattern = `%${filters.searchTerm}%`;
      conditions.push(
        sql`(
          ${documents.fileName} ILIKE ${searchPattern} OR
          ${documents.vendorName} ILIKE ${searchPattern} OR
          ${documents.invoiceNumber} ILIKE ${searchPattern} OR
          ${documents.description} ILIKE ${searchPattern}
        )`
      );
    }
    
    const whereClause = and(...conditions);
    
    // Get total count
    const [{ count }] = await db
      .select({ count: sql<number>`count(*)` })
      .from(documents)
      .where(whereClause);
    
    // Get documents with sorting
    const sortColumn = filters.sortBy === 'invoiceDate' ? documents.invoiceDate :
                      filters.sortBy === 'vendorName' ? documents.vendorName :
                      documents.createdAt;
    
    const orderBy = filters.sortOrder === 'asc' ? asc(sortColumn) : desc(sortColumn);
    
    const docsQuery = db
      .select()
      .from(documents)
      .where(whereClause)
      .orderBy(orderBy);
    
    if (filters.limit) {
      docsQuery.limit(filters.limit);
    }
    
    if (filters.offset) {
      docsQuery.offset(filters.offset);
    }
    
    const docs = await docsQuery;
    
    return { documents: docs, total: count };
  }

  async updateDocument(id: string, updates: Partial<Omit<typeof documents.$inferInsert, 'id' | 'createdAt'>>): Promise<Document | undefined> {
    const [document] = await db
      .update(documents)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(documents.id, id), eq(documents.isDeleted, false)))
      .returning();
    return document;
  }

  async deleteDocument(id: string): Promise<boolean> {
    const [document] = await db
      .update(documents)
      .set({ isDeleted: true, updatedAt: new Date() })
      .where(and(eq(documents.id, id), eq(documents.isDeleted, false)))
      .returning();
    return !!document;
  }

  // Permission operations
  async addDocumentPermission(documentId: string, userId: string, permission: string): Promise<DocumentPermission> {
    const [perm] = await db
      .insert(documentPermissions)
      .values({
        id: randomUUID(),
        documentId,
        userId,
        permission,
        createdAt: new Date(),
      })
      .returning();
    return perm;
  }

  async getUserDocumentPermission(documentId: string, userId: string): Promise<DocumentPermission | undefined> {
    const [permission] = await db
      .select()
      .from(documentPermissions)
      .where(and(
        eq(documentPermissions.documentId, documentId),
        eq(documentPermissions.userId, userId)
      ));
    return permission;
  }

  async removeDocumentPermission(documentId: string, userId: string): Promise<boolean> {
    const result = await db
      .delete(documentPermissions)
      .where(and(
        eq(documentPermissions.documentId, documentId),
        eq(documentPermissions.userId, userId)
      ));
    return result.rowCount > 0;
  }

  async getDocumentPermissions(documentId: string): Promise<DocumentPermission[]> {
    const permissions = await db
      .select()
      .from(documentPermissions)
      .where(eq(documentPermissions.documentId, documentId));
    return permissions;
  }

  async canUserAccessDocument(documentId: string, userId: string, requiredPermission: 'view' | 'edit' | 'delete'): Promise<boolean> {
    // Check if user is admin
    const user = await this.getUser(userId);
    if (user?.role === 'admin') {
      return true;
    }

    // Get the document to check ownership
    const document = await this.getDocument(documentId);
    if (!document) {
      return false;
    }

    // Check if user owns the document
    if (document.uploadedBy === userId) {
      return true;
    }

    // Check explicit permissions
    const permission = await this.getUserDocumentPermission(documentId, userId);
    if (!permission) {
      return false;
    }

    // Check if the permission level is sufficient
    const permissionHierarchy = { view: 1, edit: 2, delete: 3 };
    const userPermissionLevel = permissionHierarchy[permission.permission as keyof typeof permissionHierarchy] || 0;
    const requiredPermissionLevel = permissionHierarchy[requiredPermission];

    return userPermissionLevel >= requiredPermissionLevel;
  }

  async isUserAdmin(userId: string): Promise<boolean> {
    const user = await this.getUser(userId);
    return user?.role === 'admin';
  }

  // Analytics operations
  async getDocumentStats(filters: {
    uploadedBy?: string;
    dateFrom?: Date;
    dateTo?: Date;
  }): Promise<{
    totalDocuments: number;
    totalAmount: number;
    uniqueVendors: number;
    documentsByCategory: Array<{ category: string; count: number; amount: number }>;
    topVendors: Array<{ vendor: string; count: number; amount: number }>;
  }> {
    const conditions = [eq(documents.isDeleted, false)];
    
    if (filters.uploadedBy) {
      conditions.push(eq(documents.uploadedBy, filters.uploadedBy));
    }
    
    if (filters.dateFrom && filters.dateTo) {
      conditions.push(between(documents.invoiceDate, filters.dateFrom, filters.dateTo));
    }
    
    const whereClause = and(...conditions);
    
    // Get basic stats
    const [basicStats] = await db
      .select({
        totalDocuments: sql<number>`count(*)`,
        totalAmount: sql<number>`coalesce(sum(${documents.amount}::numeric), 0)`,
        uniqueVendors: sql<number>`count(distinct ${documents.vendorName})`,
      })
      .from(documents)
      .where(whereClause);
    
    // Get documents by category
    const categoryStats = await db
      .select({
        category: documents.category,
        count: sql<number>`count(*)`,
        amount: sql<number>`coalesce(sum(${documents.amount}::numeric), 0)`,
      })
      .from(documents)
      .where(whereClause)
      .groupBy(documents.category)
      .orderBy(sql`count(*) desc`);
    
    // Get top vendors
    const vendorStats = await db
      .select({
        vendor: documents.vendorName,
        count: sql<number>`count(*)`,
        amount: sql<number>`coalesce(sum(${documents.amount}::numeric), 0)`,
      })
      .from(documents)
      .where(whereClause)
      .groupBy(documents.vendorName)
      .orderBy(sql`count(*) desc`)
      .limit(10);
    
    return {
      totalDocuments: basicStats.totalDocuments,
      totalAmount: Number(basicStats.totalAmount),
      uniqueVendors: basicStats.uniqueVendors,
      documentsByCategory: categoryStats.map(stat => ({
        category: stat.category || 'Uncategorized',
        count: stat.count,
        amount: Number(stat.amount),
      })),
      topVendors: vendorStats.map(stat => ({
        vendor: stat.vendor,
        count: stat.count,
        amount: Number(stat.amount),
      })),
    };
  }
}

export const storage = new DatabaseStorage();