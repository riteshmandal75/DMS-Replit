import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Download, 
  Edit, 
  Trash2, 
  X,
  FileText,
  Calendar,
  User,
  Building,
  DollarSign,
  Tag
} from "lucide-react";
import { format } from "date-fns";

//todo: remove mock functionality
interface Document {
  id: string;
  fileName: string;
  vendorName: string;
  invoiceNumber: string;
  invoiceDate: Date;
  uploadedBy: string;
  uploadedAt: Date;
  fileSize: string;
  fileType: string;
  amount?: number;
  category?: string;
  description?: string;
}

interface DocumentViewerProps {
  document: Document | null;
  isOpen: boolean;
  onClose: () => void;
  onEdit?: (document: Document) => void;
  onDelete?: (document: Document) => void;
  onDownload?: (document: Document) => void;
}

export function DocumentViewer({ 
  document, 
  isOpen, 
  onClose, 
  onEdit, 
  onDelete, 
  onDownload 
}: DocumentViewerProps) {
  const [isLoading, setIsLoading] = useState(false);

  if (!document) return null;

  const handleAction = async (action: () => void, actionName: string) => {
    setIsLoading(true);
    console.log(`${actionName} triggered for document:`, document.fileName);
    try {
      action();
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="dialog-document-viewer">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Document Viewer
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              data-testid="button-close-viewer"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Document Preview */}
          <div className="lg:col-span-2">
            <div className="border rounded-lg bg-muted/30 aspect-[4/5] flex items-center justify-center">
              <div className="text-center">
                <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                <p className="text-lg font-medium" data-testid="text-preview-filename">
                  {document.fileName}
                </p>
                <p className="text-sm text-muted-foreground">
                  {document.fileType.toUpperCase()} File Preview
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  File Size: {document.fileSize}
                </p>
              </div>
            </div>
          </div>

          {/* Document Metadata */}
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-3">Document Details</h3>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Building className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Vendor</p>
                    <p className="text-sm text-muted-foreground" data-testid="text-detail-vendor">
                      {document.vendorName}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Invoice Number</p>
                    <p className="text-sm text-muted-foreground" data-testid="text-detail-invoice">
                      {document.invoiceNumber}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Invoice Date</p>
                    <p className="text-sm text-muted-foreground" data-testid="text-detail-date">
                      {format(document.invoiceDate, "MMMM dd, yyyy")}
                    </p>
                  </div>
                </div>

                {document.amount && (
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Amount</p>
                      <p className="text-sm text-muted-foreground" data-testid="text-detail-amount">
                        ${document.amount.toFixed(2)}
                      </p>
                    </div>
                  </div>
                )}

                {document.category && (
                  <div className="flex items-center gap-2">
                    <Tag className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium">Category</p>
                      <Badge variant="secondary" data-testid="badge-category">
                        {document.category}
                      </Badge>
                    </div>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Uploaded By</p>
                    <p className="text-sm text-muted-foreground" data-testid="text-detail-uploader">
                      {document.uploadedBy}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm font-medium">Upload Date</p>
                    <p className="text-sm text-muted-foreground" data-testid="text-detail-upload-date">
                      {format(document.uploadedAt, "MMMM dd, yyyy 'at' h:mm a")}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {document.description && (
              <div>
                <h4 className="font-medium mb-2">Description</h4>
                <p className="text-sm text-muted-foreground" data-testid="text-detail-description">
                  {document.description}
                </p>
              </div>
            )}

            {/* Action Buttons */}
            <div className="space-y-2 pt-4 border-t">
              <Button
                className="w-full"
                onClick={() => handleAction(() => onDownload?.(document), "Download")}
                disabled={isLoading}
                data-testid="button-viewer-download"
              >
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
              
              <Button
                variant="outline"
                className="w-full"
                onClick={() => handleAction(() => onEdit?.(document), "Edit")}
                disabled={isLoading}
                data-testid="button-viewer-edit"
              >
                <Edit className="h-4 w-4 mr-2" />
                Edit Details
              </Button>
              
              <Button
                variant="destructive"
                className="w-full"
                onClick={() => handleAction(() => onDelete?.(document), "Delete")}
                disabled={isLoading}
                data-testid="button-viewer-delete"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Document
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}