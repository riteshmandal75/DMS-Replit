import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { 
  Filter, 
  Search, 
  X, 
  Calendar,
  Building,
  User,
  RefreshCw
} from "lucide-react";

interface FilterState {
  searchTerm: string;
  vendor: string;
  dateFrom: string;
  dateTo: string;
  uploadedBy: string;
  category: string;
}

interface DocumentFiltersProps {
  onFiltersChange?: (filters: FilterState) => void;
  vendors?: string[];
  uploaders?: string[];
  categories?: string[];
}

export function DocumentFilters({ 
  onFiltersChange,
  vendors = [],
  uploaders = [],
  categories = []
}: DocumentFiltersProps) {
  const [filters, setFilters] = useState<FilterState>({
    searchTerm: "",
    vendor: "all",
    dateFrom: "",
    dateTo: "",
    uploadedBy: "all",
    category: "all",
  });

  const handleFilterChange = (key: keyof FilterState, value: string) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFiltersChange?.(newFilters);
    console.log('Filters updated:', newFilters);
  };

  const clearFilters = () => {
    const emptyFilters: FilterState = {
      searchTerm: "",
      vendor: "all",
      dateFrom: "",
      dateTo: "",
      uploadedBy: "all",
      category: "all",
    };
    setFilters(emptyFilters);
    onFiltersChange?.(emptyFilters);
    console.log('Filters cleared');
  };

  const getActiveFiltersCount = () => {
    return Object.entries(filters).filter(([key, value]) => {
      if (key === 'vendor' || key === 'uploadedBy' || key === 'category') {
        return value !== "" && value !== "all";
      }
      return value !== "";
    }).length;
  };

  const activeFiltersCount = getActiveFiltersCount();

  //todo: remove mock functionality
  const mockVendors = vendors.length > 0 ? vendors : [
    "ABC Supply Co", 
    "Tech Solutions Inc", 
    "Office Depot", 
    "Amazon Business", 
    "Staples"
  ];
  
  const mockUploaders = uploaders.length > 0 ? uploaders : [
    "John Smith", 
    "Sarah Johnson", 
    "Mike Davis", 
    "Lisa Chen", 
    "Robert Wilson"
  ];
  
  const mockCategories = categories.length > 0 ? categories : [
    "Office Supplies", 
    "Technology", 
    "Travel", 
    "Utilities", 
    "Marketing"
  ];

  return (
    <Card data-testid="filters-panel">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filters
            {activeFiltersCount > 0 && (
              <Badge variant="secondary" data-testid="badge-active-filters">
                {activeFiltersCount}
              </Badge>
            )}
          </div>
          {activeFiltersCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              data-testid="button-clear-filters"
            >
              <RefreshCw className="h-4 w-4 mr-1" />
              Clear
            </Button>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search */}
        <div className="space-y-2">
          <Label htmlFor="search">Search Documents</Label>
          <div className="relative">
            <Search className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
            <Input
              id="search"
              placeholder="Search by filename, vendor, or invoice number..."
              value={filters.searchTerm}
              onChange={(e) => handleFilterChange("searchTerm", e.target.value)}
              className="pl-9"
              data-testid="input-search-documents"
            />
          </div>
        </div>

        {/* Vendor Filter */}
        <div className="space-y-2">
          <Label>Vendor</Label>
          <Select 
            value={filters.vendor} 
            onValueChange={(value) => handleFilterChange("vendor", value)}
          >
            <SelectTrigger data-testid="select-vendor">
              <div className="flex items-center gap-2">
                <Building className="h-4 w-4 text-muted-foreground" />
                <SelectValue placeholder="All Vendors" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Vendors</SelectItem>
              {mockVendors.map((vendor) => (
                <SelectItem key={vendor} value={vendor}>
                  {vendor}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Date Range */}
        <div className="space-y-2">
          <Label>Date Range</Label>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="dateFrom" className="text-xs text-muted-foreground">From</Label>
              <Input
                id="dateFrom"
                type="date"
                value={filters.dateFrom}
                onChange={(e) => handleFilterChange("dateFrom", e.target.value)}
                data-testid="input-date-from"
              />
            </div>
            <div>
              <Label htmlFor="dateTo" className="text-xs text-muted-foreground">To</Label>
              <Input
                id="dateTo"
                type="date"
                value={filters.dateTo}
                onChange={(e) => handleFilterChange("dateTo", e.target.value)}
                data-testid="input-date-to"
              />
            </div>
          </div>
        </div>

        {/* Uploaded By Filter */}
        <div className="space-y-2">
          <Label>Uploaded By</Label>
          <Select 
            value={filters.uploadedBy} 
            onValueChange={(value) => handleFilterChange("uploadedBy", value)}
          >
            <SelectTrigger data-testid="select-uploader">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <SelectValue placeholder="All Users" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Users</SelectItem>
              {mockUploaders.map((uploader) => (
                <SelectItem key={uploader} value={uploader}>
                  {uploader}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Category Filter */}
        <div className="space-y-2">
          <Label>Category</Label>
          <Select 
            value={filters.category} 
            onValueChange={(value) => handleFilterChange("category", value)}
          >
            <SelectTrigger data-testid="select-category">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {mockCategories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Active Filters Display */}
        {activeFiltersCount > 0 && (
          <div className="space-y-2 pt-2 border-t">
            <Label className="text-sm">Active Filters:</Label>
            <div className="flex flex-wrap gap-1">
              {filters.searchTerm && (
                <Badge variant="secondary" className="text-xs" data-testid="active-filter-search">
                  Search: {filters.searchTerm}
                  <X 
                    className="h-3 w-3 ml-1 cursor-pointer" 
                    onClick={() => handleFilterChange("searchTerm", "")}
                  />
                </Badge>
              )}
              {filters.vendor && filters.vendor !== "all" && (
                <Badge variant="secondary" className="text-xs" data-testid="active-filter-vendor">
                  Vendor: {filters.vendor}
                  <X 
                    className="h-3 w-3 ml-1 cursor-pointer" 
                    onClick={() => handleFilterChange("vendor", "all")}
                  />
                </Badge>
              )}
              {(filters.dateFrom || filters.dateTo) && (
                <Badge variant="secondary" className="text-xs" data-testid="active-filter-date">
                  Date: {filters.dateFrom || "..."} - {filters.dateTo || "..."}
                  <X 
                    className="h-3 w-3 ml-1 cursor-pointer" 
                    onClick={() => {
                      handleFilterChange("dateFrom", "");
                      handleFilterChange("dateTo", "");
                    }}
                  />
                </Badge>
              )}
              {filters.uploadedBy && filters.uploadedBy !== "all" && (
                <Badge variant="secondary" className="text-xs" data-testid="active-filter-uploader">
                  User: {filters.uploadedBy}
                  <X 
                    className="h-3 w-3 ml-1 cursor-pointer" 
                    onClick={() => handleFilterChange("uploadedBy", "all")}
                  />
                </Badge>
              )}
              {filters.category && filters.category !== "all" && (
                <Badge variant="secondary" className="text-xs" data-testid="active-filter-category">
                  Category: {filters.category}
                  <X 
                    className="h-3 w-3 ml-1 cursor-pointer" 
                    onClick={() => handleFilterChange("category", "all")}
                  />
                </Badge>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}