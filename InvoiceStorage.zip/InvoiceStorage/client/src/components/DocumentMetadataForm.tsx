import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { CalendarDays, Save } from "lucide-react";
import { format } from "date-fns";

interface DocumentMetadata {
  vendorName: string;
  invoiceNumber: string;
  invoiceDate: string;
  description?: string;
  amount?: string;
  category?: string;
}

interface DocumentMetadataFormProps {
  onSave?: (metadata: DocumentMetadata) => void;
  initialData?: Partial<DocumentMetadata>;
  isLoading?: boolean;
}

export function DocumentMetadataForm({ 
  onSave, 
  initialData, 
  isLoading = false 
}: DocumentMetadataFormProps) {
  const [formData, setFormData] = useState<DocumentMetadata>({
    vendorName: initialData?.vendorName || "",
    invoiceNumber: initialData?.invoiceNumber || "",
    invoiceDate: initialData?.invoiceDate || format(new Date(), "yyyy-MM-dd"),
    description: initialData?.description || "",
    amount: initialData?.amount || "",
    category: initialData?.category || "",
  });

  const [errors, setErrors] = useState<Partial<DocumentMetadata>>({});

  const validateForm = (): boolean => {
    const newErrors: Partial<DocumentMetadata> = {};

    if (!formData.vendorName.trim()) {
      newErrors.vendorName = "Vendor name is required";
    }

    if (!formData.invoiceNumber.trim()) {
      newErrors.invoiceNumber = "Invoice number is required";
    }

    if (!formData.invoiceDate) {
      newErrors.invoiceDate = "Invoice date is required";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      console.log('Form submitted with data:', formData);
      onSave?.(formData);
    }
  };

  const handleInputChange = (field: keyof DocumentMetadata, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user starts typing
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const generateFileName = () => {
    if (formData.vendorName && formData.invoiceNumber) {
      return `${formData.vendorName.replace(/[^a-zA-Z0-9]/g, '_')}_Invoice_${formData.invoiceNumber.replace(/[^a-zA-Z0-9]/g, '_')}`;
    }
    return "";
  };

  return (
    <Card data-testid="form-document-metadata">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CalendarDays className="h-5 w-5" />
          Document Information
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="vendorName">Vendor Name *</Label>
              <Input
                id="vendorName"
                value={formData.vendorName}
                onChange={(e) => handleInputChange("vendorName", e.target.value)}
                placeholder="Enter vendor name"
                className={errors.vendorName ? "border-destructive" : ""}
                data-testid="input-vendor-name"
              />
              {errors.vendorName && (
                <p className="text-sm text-destructive" data-testid="error-vendor-name">
                  {errors.vendorName}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="invoiceNumber">Invoice Number *</Label>
              <Input
                id="invoiceNumber"
                value={formData.invoiceNumber}
                onChange={(e) => handleInputChange("invoiceNumber", e.target.value)}
                placeholder="Enter invoice number"
                className={errors.invoiceNumber ? "border-destructive" : ""}
                data-testid="input-invoice-number"
              />
              {errors.invoiceNumber && (
                <p className="text-sm text-destructive" data-testid="error-invoice-number">
                  {errors.invoiceNumber}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="invoiceDate">Invoice Date *</Label>
              <Input
                id="invoiceDate"
                type="date"
                value={formData.invoiceDate}
                onChange={(e) => handleInputChange("invoiceDate", e.target.value)}
                className={errors.invoiceDate ? "border-destructive" : ""}
                data-testid="input-invoice-date"
              />
              {errors.invoiceDate && (
                <p className="text-sm text-destructive" data-testid="error-invoice-date">
                  {errors.invoiceDate}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={(e) => handleInputChange("amount", e.target.value)}
                placeholder="0.00"
                data-testid="input-amount"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                value={formData.category}
                onChange={(e) => handleInputChange("category", e.target.value)}
                placeholder="e.g., Office Supplies, Travel, etc."
                data-testid="input-category"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => handleInputChange("description", e.target.value)}
              placeholder="Additional notes or description..."
              rows={3}
              data-testid="input-description"
            />
          </div>

          {generateFileName() && (
            <div className="bg-muted p-3 rounded-md">
              <Label className="text-sm font-medium">Generated File Name:</Label>
              <p className="text-sm text-muted-foreground mt-1" data-testid="text-generated-filename">
                {generateFileName()}
              </p>
            </div>
          )}

          <div className="flex gap-2 pt-4">
            <Button
              type="submit"
              disabled={isLoading}
              data-testid="button-save-metadata"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current mr-2" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Save Document
                </>
              )}
            </Button>
            
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setFormData({
                  vendorName: "",
                  invoiceNumber: "",
                  invoiceDate: format(new Date(), "yyyy-MM-dd"),
                  description: "",
                  amount: "",
                  category: "",
                });
                setErrors({});
                console.log('Form reset');
              }}
              disabled={isLoading}
              data-testid="button-reset-form"
            >
              Reset
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}