import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Download, 
  Edit, 
  Trash2, 
  Eye,
  Calendar,
  User,
  Building
} from "lucide-react";
import { format } from "date-fns";

//todo: remove mock functionality
interface Document {
  id: string;
  fileName: string;
  vendorName: string;
  invoiceNumber: string;
  invoiceDate: Date;
  uploadedBy: string;
  uploadedAt: Date;
  fileSize: string;
  fileType: string;
}

interface DocumentCardProps {
  document: Document;
  onView?: (document: Document) => void;
  onEdit?: (document: Document) => void;
  onDelete?: (document: Document) => void;
  onDownload?: (document: Document) => void;
}

export function DocumentCard({ 
  document, 
  onView, 
  onEdit, 
  onDelete, 
  onDownload 
}: DocumentCardProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleAction = async (action: () => void, actionName: string) => {
    setIsLoading(true);
    console.log(`${actionName} triggered for document:`, document.fileName);
    try {
      action();
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="hover-elevate" data-testid={`card-document-${document.id}`}>
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-muted-foreground" />
            <div className="flex-1 min-w-0">
              <h3 className="font-medium truncate" data-testid={`text-filename-${document.id}`}>
                {document.fileName}
              </h3>
              <Badge variant="secondary" className="text-xs mt-1">
                {document.fileType.toUpperCase()}
              </Badge>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-2">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Building className="h-3 w-3" />
          <span data-testid={`text-vendor-${document.id}`}>{document.vendorName}</span>
        </div>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <FileText className="h-3 w-3" />
          <span data-testid={`text-invoice-${document.id}`}>Invoice #{document.invoiceNumber}</span>
        </div>

        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calendar className="h-3 w-3" />
          <span data-testid={`text-date-${document.id}`}>
            {format(document.invoiceDate, "MMM dd, yyyy")}
          </span>
        </div>

        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <User className="h-3 w-3" />
          <span data-testid={`text-uploader-${document.id}`}>{document.uploadedBy}</span>
        </div>

        <div className="text-xs text-muted-foreground">
          Size: {document.fileSize} • Uploaded {format(document.uploadedAt, "MMM dd, yyyy")}
        </div>
      </CardContent>

      <CardFooter className="flex gap-2 pt-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleAction(() => onView?.(document), "View")}
          disabled={isLoading}
          data-testid={`button-view-${document.id}`}
        >
          <Eye className="h-3 w-3 mr-1" />
          View
        </Button>
        
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleAction(() => onDownload?.(document), "Download")}
          disabled={isLoading}
          data-testid={`button-download-${document.id}`}
        >
          <Download className="h-3 w-3 mr-1" />
          Download
        </Button>
        
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleAction(() => onEdit?.(document), "Edit")}
          disabled={isLoading}
          data-testid={`button-edit-${document.id}`}
        >
          <Edit className="h-3 w-3 mr-1" />
          Edit
        </Button>
        
        <Button
          variant="destructive"
          size="sm"
          onClick={() => handleAction(() => onDelete?.(document), "Delete")}
          disabled={isLoading}
          data-testid={`button-delete-${document.id}`}
        >
          <Trash2 className="h-3 w-3 mr-1" />
          Delete
        </Button>
      </CardFooter>
    </Card>
  );
}