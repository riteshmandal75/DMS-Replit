import { useState } from "react";
import { FileUploadZone } from "@/components/FileUploadZone";
import { DocumentMetadataForm } from "@/components/DocumentMetadataForm";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Upload, CheckCircle, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function UploadDocument() {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [uploadStep, setUploadStep] = useState<"upload" | "metadata" | "success">("upload");
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFilesSelected = (files: File[]) => {
    console.log('Files selected for upload:', files.map(f => f.name));
    setSelectedFiles(files);
    if (files.length > 0) {
      setUploadStep("metadata");
    }
  };

  const handleMetadataSave = async (metadata: any) => {
    setIsProcessing(true);
    console.log('Processing document with metadata:', {
      files: selectedFiles.map(f => f.name),
      metadata
    });

    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 3000));

    setIsProcessing(false);
    setUploadStep("success");
  };

  const handleStartOver = () => {
    setSelectedFiles([]);
    setUploadStep("upload");
    setIsProcessing(false);
    console.log('Upload process reset');
  };

  const StepIndicator = () => (
    <div className="flex items-center justify-center mb-8">
      <div className="flex items-center space-x-4">
        <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
          uploadStep === "upload" ? "bg-primary text-primary-foreground" : 
          uploadStep === "metadata" || uploadStep === "success" ? "bg-primary text-primary-foreground" : 
          "bg-muted text-muted-foreground"
        }`}>
          1
        </div>
        <div className={`w-12 h-px ${
          uploadStep === "metadata" || uploadStep === "success" ? "bg-primary" : "bg-muted"
        }`} />
        <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
          uploadStep === "metadata" ? "bg-primary text-primary-foreground" : 
          uploadStep === "success" ? "bg-primary text-primary-foreground" : 
          "bg-muted text-muted-foreground"
        }`}>
          2
        </div>
        <div className={`w-12 h-px ${
          uploadStep === "success" ? "bg-primary" : "bg-muted"
        }`} />
        <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
          uploadStep === "success" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
        }`}>
          3
        </div>
      </div>
    </div>
  );

  if (uploadStep === "success") {
    return (
      <div className="max-w-2xl mx-auto space-y-6" data-testid="page-upload-success">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" asChild data-testid="button-back-dashboard">
            <Link href="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
        </div>

        <StepIndicator />

        <Card className="text-center">
          <CardContent className="pt-6">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Upload Successful!</h2>
            <p className="text-muted-foreground mb-6">
              Your document{selectedFiles.length > 1 ? 's have' : ' has'} been successfully uploaded and processed.
            </p>
            
            <div className="bg-muted/30 p-4 rounded-lg mb-6">
              <h3 className="font-medium mb-2">Uploaded Files:</h3>
              {selectedFiles.map((file, index) => (
                <p key={index} className="text-sm text-muted-foreground" data-testid={`success-file-${index}`}>
                  {file.name}
                </p>
              ))}
            </div>

            <div className="flex gap-4 justify-center">
              <Button onClick={handleStartOver} data-testid="button-upload-another">
                Upload Another Document
              </Button>
              <Button variant="outline" asChild data-testid="button-view-documents">
                <Link href="/documents">
                  View All Documents
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6" data-testid="page-upload-document">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" asChild data-testid="button-back-dashboard">
          <Link href="/">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
      </div>

      <div>
        <h1 className="text-3xl font-bold mb-2">Upload Document</h1>
        <p className="text-muted-foreground">
          Upload scanned invoices and add metadata for proper organization.
        </p>
      </div>

      <StepIndicator />

      {uploadStep === "upload" && (
        <div className="space-y-6">
          <Card data-testid="upload-step">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Step 1: Select Files
              </CardTitle>
            </CardHeader>
            <CardContent>
              <FileUploadZone onFilesSelected={handleFilesSelected} />
            </CardContent>
          </Card>
        </div>
      )}

      {uploadStep === "metadata" && (
        <div className="space-y-6">
          <Card data-testid="metadata-step">
            <CardHeader>
              <CardTitle>Step 2: Add Document Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-6">
                <h3 className="font-medium mb-2">Selected Files:</h3>
                <div className="space-y-1">
                  {selectedFiles.map((file, index) => (
                    <p key={index} className="text-sm text-muted-foreground" data-testid={`selected-file-${index}`}>
                      {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
                    </p>
                  ))}
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <DocumentMetadataForm 
                onSave={handleMetadataSave}
                isLoading={isProcessing}
              />
            </CardContent>
          </Card>

          <div className="flex gap-4">
            <Button 
              variant="outline" 
              onClick={() => setUploadStep("upload")}
              disabled={isProcessing}
              data-testid="button-back-to-upload"
            >
              Back to File Selection
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}