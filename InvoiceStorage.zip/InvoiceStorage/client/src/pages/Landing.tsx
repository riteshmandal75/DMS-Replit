import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  FileText, 
  Shield, 
  Search, 
  Upload,
  BarChart3,
  Users,
  CheckCircle
} from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    console.log('Login triggered');
    window.location.href = '/api/login';
  };

  const features = [
    {
      icon: Upload,
      title: "Easy Upload",
      description: "Drag and drop scanned invoices with automatic file naming using vendor names and invoice numbers."
    },
    {
      icon: FileText,
      title: "Smart Organization",
      description: "Automatic file naming convention ensures documents are properly categorized and easy to find."
    },
    {
      icon: Search,
      title: "Powerful Search",
      description: "Find documents quickly with advanced filtering by vendor, date range, user, and category."
    },
    {
      icon: Shield,
      title: "User Authorization",
      description: "Role-based permissions control who can view, edit, or delete documents in your organization."
    },
    {
      icon: BarChart3,
      title: "Date-wise Reports",
      description: "Generate comprehensive reports with date range filtering and export capabilities."
    },
    {
      icon: Users,
      title: "Multi-user Support",
      description: "Track document uploads by user with complete audit trails and activity logs."
    }
  ];

  const benefits = [
    "Secure cloud storage for all scanned documents",
    "Automated naming convention reduces errors",
    "Role-based access control for team security",
    "Advanced search and filtering capabilities",
    "Comprehensive audit trails and reporting",
    "Mobile-friendly interface for remote access"
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileText className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold">DocManager</h1>
            </div>
            <Button onClick={handleLogin} data-testid="button-login">
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-b from-primary/5 to-background">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            Secure Document Management 
            <span className="text-primary block">Made Simple</span>
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Store, organize, and manage your scanned invoices with enterprise-grade security, 
            intelligent naming conventions, and powerful search capabilities.
          </p>
          <Button 
            size="lg" 
            onClick={handleLogin}
            className="text-lg px-8 py-6"
            data-testid="button-get-started"
          >
            Get Started Today
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold mb-4">Powerful Features</h3>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Everything you need to manage your document workflow efficiently and securely.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="hover-elevate" data-testid={`feature-card-${index}`}>
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <feature.icon className="h-8 w-8 text-primary" />
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold mb-6">Why Choose DocManager?</h3>
              <p className="text-lg text-muted-foreground mb-8">
                Built specifically for businesses that need to manage large volumes of 
                scanned invoices and documents with precision and security.
              </p>
              <div className="space-y-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center gap-3" data-testid={`benefit-${index}`}>
                    <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                    <span>{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <Card className="p-6">
              <div className="text-center">
                <FileText className="h-16 w-16 text-primary mx-auto mb-4" />
                <h4 className="text-2xl font-bold mb-4">Ready to Get Started?</h4>
                <p className="text-muted-foreground mb-6">
                  Join hundreds of businesses already using DocManager to streamline 
                  their document workflows.
                </p>
                <Button 
                  size="lg" 
                  onClick={handleLogin}
                  className="w-full"
                  data-testid="button-cta-signup"
                >
                  Start Managing Documents
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-card py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <FileText className="h-6 w-6 text-primary" />
            <span className="text-lg font-semibold">DocManager</span>
          </div>
          <p className="text-muted-foreground">
            Secure document management for modern businesses.
          </p>
        </div>
      </footer>
    </div>
  );
}