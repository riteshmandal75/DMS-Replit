import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  ArrowLeft, 
  Download, 
  Calendar,
  BarChart3,
  FileText,
  DollarSign,
  Building,
  TrendingUp,
  Filter
} from "lucide-react";
import { Link } from "wouter";
import { format, subDays, subWeeks, subMonths } from "date-fns";

export default function Reports() {
  const [dateFrom, setDateFrom] = useState(format(subMonths(new Date(), 1), "yyyy-MM-dd"));
  const [dateTo, setDateTo] = useState(format(new Date(), "yyyy-MM-dd"));
  const [selectedVendor, setSelectedVendor] = useState("all");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [reportType, setReportType] = useState("summary");
  const [isGenerating, setIsGenerating] = useState(false);

  // Build query parameters for analytics API
  const buildAnalyticsParams = () => {
    const params = new URLSearchParams();
    if (dateFrom) params.append('dateFrom', dateFrom);
    if (dateTo) params.append('dateTo', dateTo);
    if (selectedVendor !== 'all') params.append('vendorName', selectedVendor);
    return params.toString();
  };

  // Fetch analytics data from API
  const { data: analyticsData, isLoading: analyticsLoading, error: analyticsError } = useQuery({
    queryKey: ['/api/analytics/stats', dateFrom, dateTo, selectedVendor],
    queryFn: async () => {
      const response = await fetch(`/api/analytics/stats?${buildAnalyticsParams()}`);
      if (!response.ok) {
        throw new Error('Failed to fetch analytics data');
      }
      return response.json();
    },
    staleTime: 60000, // 1 minute
  });

  // Use analytics data or provide fallback
  const reportData = analyticsData || {
    totalDocuments: 0,
    totalAmount: 0,
    uniqueVendors: 0,
    documentsByCategory: [],
    topVendors: []
  };
  
  const avgDocumentValue = reportData.totalDocuments > 0 ? reportData.totalAmount / reportData.totalDocuments : 0;

  const quickDateRanges = [
    { label: "Last 7 days", days: 7 },
    { label: "Last 30 days", days: 30 },
    { label: "Last 90 days", days: 90 },
    { label: "Last 6 months", days: 180 },
    { label: "Last year", days: 365 }
  ];

  const handleQuickDateRange = (days: number) => {
    const endDate = new Date();
    const startDate = subDays(endDate, days);
    setDateFrom(format(startDate, "yyyy-MM-dd"));
    setDateTo(format(endDate, "yyyy-MM-dd"));
    console.log(`Date range set to last ${days} days`);
  };

  const handleGenerateReport = async () => {
    setIsGenerating(true);
    console.log('Generating report with params:', {
      dateFrom,
      dateTo,
      vendor: selectedVendor,
      category: selectedCategory,
      type: reportType
    });
    
    // Simulate report generation
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsGenerating(false);
  };

  const handleExportReport = async (format: "pdf" | "excel") => {
    try {
      console.log(`Exporting report as ${format}`);
      
      // Build export parameters
      const params = new URLSearchParams();
      if (dateFrom) params.append('dateFrom', dateFrom);
      if (dateTo) params.append('dateTo', dateTo);
      if (selectedVendor !== 'all') params.append('vendorName', selectedVendor);
      if (selectedCategory !== 'all') params.append('category', selectedCategory);
      
      // Determine endpoint
      const endpoint = format === 'excel' ? '/api/reports/export/excel' : '/api/reports/export/csv';
      
      // Create download link
      const response = await fetch(`${endpoint}?${params.toString()}`);
      
      if (!response.ok) {
        throw new Error(`Export failed: ${response.statusText}`);
      }
      
      // Get the blob and create download
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      
      // Extract filename from response headers or create default
      const contentDisposition = response.headers.get('content-disposition');
      const filename = contentDisposition 
        ? contentDisposition.split('filename=')[1]?.replace(/"/g, '') 
        : `documents-export-${new Date().toISOString().split('T')[0]}.${format === 'excel' ? 'xls' : 'csv'}`;
      
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      console.log(`Successfully exported ${format} report`);
    } catch (error) {
      console.error(`Export ${format} error:`, error);
      // In a real app, you'd show a toast notification here
    }
  };

  return (
    <div className="space-y-6" data-testid="page-reports">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" asChild data-testid="button-back-dashboard">
          <Link href="/">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
      </div>

      <div>
        <h1 className="text-3xl font-bold mb-2">Reports</h1>
        <p className="text-muted-foreground">
          Generate detailed reports based on date ranges and filtering criteria.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Report Configuration */}
        <div className="lg:col-span-1">
          <Card data-testid="report-configuration">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Report Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Report Type */}
              <div className="space-y-2">
                <Label>Report Type</Label>
                <Select value={reportType} onValueChange={setReportType}>
                  <SelectTrigger data-testid="select-report-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="summary">Summary Report</SelectItem>
                    <SelectItem value="detailed">Detailed Report</SelectItem>
                    <SelectItem value="vendor">Vendor Analysis</SelectItem>
                    <SelectItem value="category">Category Breakdown</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Quick Date Ranges */}
              <div className="space-y-2">
                <Label>Quick Date Ranges</Label>
                <div className="grid grid-cols-1 gap-1">
                  {quickDateRanges.map((range) => (
                    <Button
                      key={range.days}
                      variant="ghost"
                      size="sm"
                      onClick={() => handleQuickDateRange(range.days)}
                      className="justify-start"
                      data-testid={`button-quick-range-${range.days}`}
                    >
                      {range.label}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Custom Date Range */}
              <div className="space-y-2">
                <Label>Custom Date Range</Label>
                <div className="space-y-2">
                  <div>
                    <Label htmlFor="dateFrom" className="text-xs text-muted-foreground">From</Label>
                    <Input
                      id="dateFrom"
                      type="date"
                      value={dateFrom}
                      onChange={(e) => setDateFrom(e.target.value)}
                      data-testid="input-date-from"
                    />
                  </div>
                  <div>
                    <Label htmlFor="dateTo" className="text-xs text-muted-foreground">To</Label>
                    <Input
                      id="dateTo"
                      type="date"
                      value={dateTo}
                      onChange={(e) => setDateTo(e.target.value)}
                      data-testid="input-date-to"
                    />
                  </div>
                </div>
              </div>

              {/* Vendor Filter */}
              <div className="space-y-2">
                <Label>Vendor (Optional)</Label>
                <Select value={selectedVendor} onValueChange={setSelectedVendor}>
                  <SelectTrigger data-testid="select-vendor-filter">
                    <SelectValue placeholder="All Vendors" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Vendors</SelectItem>
                    <SelectItem value="ABC Supply Co">ABC Supply Co</SelectItem>
                    <SelectItem value="Tech Solutions Inc">Tech Solutions Inc</SelectItem>
                    <SelectItem value="Office Depot">Office Depot</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Category Filter */}
              <div className="space-y-2">
                <Label>Category (Optional)</Label>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger data-testid="select-category-filter">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="Office Supplies">Office Supplies</SelectItem>
                    <SelectItem value="Technology">Technology</SelectItem>
                    <SelectItem value="Travel">Travel</SelectItem>
                    <SelectItem value="Utilities">Utilities</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button 
                className="w-full" 
                onClick={handleGenerateReport}
                disabled={isGenerating}
                data-testid="button-generate-report"
              >
                {isGenerating ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current mr-2" />
                    Generating...
                  </>
                ) : (
                  <>
                    <BarChart3 className="h-4 w-4 mr-2" />
                    Generate Report
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Report Results */}
        <div className="lg:col-span-3 space-y-6">
          {/* Report Header */}
          <Card data-testid="report-header">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Report: {format(new Date(dateFrom), "MMM dd, yyyy")} - {format(new Date(dateTo), "MMM dd, yyyy")}
                  </CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">
                    {selectedVendor && selectedVendor !== "all" && `Vendor: ${selectedVendor} • `}
                    {selectedCategory && selectedCategory !== "all" && `Category: ${selectedCategory} • `}
                    Report Type: {reportType.charAt(0).toUpperCase() + reportType.slice(1)}
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleExportReport("pdf")}
                    data-testid="button-export-pdf"
                  >
                    <Download className="h-4 w-4 mr-1" />
                    PDF
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleExportReport("excel")}
                    data-testid="button-export-excel"
                  >
                    <Download className="h-4 w-4 mr-1" />
                    Excel
                  </Button>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Summary Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card data-testid="stat-total-documents">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <FileText className="h-8 w-8 text-primary" />
                  <div>
                    <div className="text-2xl font-bold">{reportData.totalDocuments}</div>
                    <p className="text-sm text-muted-foreground">Documents</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card data-testid="stat-total-amount">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <DollarSign className="h-8 w-8 text-green-600" />
                  <div>
                    <div className="text-2xl font-bold">${reportData.totalAmount.toLocaleString()}</div>
                    <p className="text-sm text-muted-foreground">Total Amount</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card data-testid="stat-unique-vendors">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <Building className="h-8 w-8 text-blue-600" />
                  <div>
                    <div className="text-2xl font-bold">{reportData.uniqueVendors}</div>
                    <p className="text-sm text-muted-foreground">Vendors</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card data-testid="stat-avg-amount">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <TrendingUp className="h-8 w-8 text-orange-600" />
                  <div>
                    <div className="text-2xl font-bold">${avgDocumentValue.toFixed(0)}</div>
                    <p className="text-sm text-muted-foreground">Avg. Value</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Category Breakdown */}
          <Card data-testid="category-breakdown">
            <CardHeader>
              <CardTitle>Documents by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reportData.documentsByCategory.map((category: any, index: number) => (
                  <div key={category.category} className="flex items-center justify-between p-3 border rounded-lg" data-testid={`category-item-${index}`}>
                    <div className="flex items-center gap-3">
                      <Badge variant="secondary">{category.count}</Badge>
                      <span className="font-medium">{category.category}</span>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">${category.amount.toLocaleString()}</div>
                      <div className="text-sm text-muted-foreground">
                        {reportData.totalAmount > 0 ? ((category.amount / reportData.totalAmount) * 100).toFixed(1) : 0}% of total
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Top Vendors */}
          <Card data-testid="top-vendors">
            <CardHeader>
              <CardTitle>Top Vendors</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reportData.topVendors.map((vendor: any, index: number) => (
                  <div key={vendor.vendor} className="flex items-center justify-between p-3 border rounded-lg" data-testid={`vendor-item-${index}`}>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center justify-center w-8 h-8 bg-primary/10 rounded-full text-sm font-medium">
                        {index + 1}
                      </div>
                      <div>
                        <div className="font-medium">{vendor.vendor}</div>
                        <div className="text-sm text-muted-foreground">{vendor.count} documents</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">${vendor.amount.toLocaleString()}</div>
                      <div className="text-sm text-muted-foreground">
                        Avg: ${(vendor.amount / vendor.count).toFixed(0)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}