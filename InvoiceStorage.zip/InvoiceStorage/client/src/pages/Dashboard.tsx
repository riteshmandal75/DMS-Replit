import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  FileText, 
  Upload, 
  TrendingUp, 
  Calendar,
  Users,
  Building,
  BarChart3,
  Plus,
  Eye
} from "lucide-react";
import { format, subDays } from "date-fns";
import { useAuth } from "@/hooks/useAuth";
import { Link } from "wouter";

export default function Dashboard() {
  const { user } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState("30");

  //todo: remove mock functionality
  const mockStats = {
    totalDocuments: 1247,
    documentsThisMonth: 156,
    totalVendors: 89,
    pendingReviews: 12,
    avgProcessingTime: "2.3 days"
  };

  const mockRecentDocuments = [
    {
      id: "1",
      fileName: "ABC_Supply_Invoice_INV-2024-001.pdf",
      vendorName: "ABC Supply Co",
      invoiceNumber: "INV-2024-001",
      uploadedBy: "John Smith",
      uploadedAt: new Date(),
      status: "Processed"
    },
    {
      id: "2", 
      fileName: "Tech_Solutions_Invoice_TS-5567.pdf",
      vendorName: "Tech Solutions Inc",
      invoiceNumber: "TS-5567",
      uploadedBy: "Sarah Johnson",
      uploadedAt: subDays(new Date(), 1),
      status: "Under Review"
    },
    {
      id: "3",
      fileName: "Office_Depot_Invoice_OD-8891.pdf",
      vendorName: "Office Depot",
      invoiceNumber: "OD-8891",
      uploadedBy: "Mike Davis",
      uploadedAt: subDays(new Date(), 2),
      status: "Processed"
    }
  ];

  const mockTopVendors = [
    { name: "ABC Supply Co", documentCount: 45, totalAmount: 125430 },
    { name: "Tech Solutions Inc", documentCount: 38, totalAmount: 89750 },
    { name: "Office Depot", documentCount: 29, totalAmount: 34620 },
    { name: "Amazon Business", documentCount: 22, totalAmount: 18950 },
    { name: "Staples", documentCount: 18, totalAmount: 12340 }
  ];

  const quickActions = [
    {
      title: "Upload Documents",
      description: "Add new scanned invoices",
      icon: Upload,
      href: "/upload",
      color: "bg-primary"
    },
    {
      title: "View All Documents",
      description: "Browse document library",
      icon: FileText,
      href: "/documents",
      color: "bg-secondary"
    },
    {
      title: "Generate Report",
      description: "Create date-wise reports",
      icon: BarChart3,
      href: "/reports",
      color: "bg-accent"
    }
  ];

  const getStatusBadge = (status: string) => {
    const variant = status === "Processed" ? "default" : "secondary";
    return <Badge variant={variant}>{status}</Badge>;
  };

  return (
    <div className="space-y-6" data-testid="page-dashboard">
      {/* Welcome Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Welcome back{(user as any)?.firstName ? `, ${(user as any).firstName}` : ''}!</h1>
          <p className="text-muted-foreground">
            Here's an overview of your document management activity.
          </p>
        </div>
        <Button asChild data-testid="button-upload-quick">
          <Link href="/upload">
            <Plus className="h-4 w-4 mr-2" />
            Upload Document
          </Link>
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card data-testid="stat-total-documents">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Documents</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.totalDocuments.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              +{mockStats.documentsThisMonth} this month
            </p>
          </CardContent>
        </Card>

        <Card data-testid="stat-vendors">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Vendors</CardTitle>
            <Building className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.totalVendors}</div>
            <p className="text-xs text-muted-foreground">
              Unique vendor relationships
            </p>
          </CardContent>
        </Card>

        <Card data-testid="stat-pending">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Reviews</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.pendingReviews}</div>
            <p className="text-xs text-muted-foreground">
              Require attention
            </p>
          </CardContent>
        </Card>

        <Card data-testid="stat-processing-time">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Processing</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockStats.avgProcessingTime}</div>
            <p className="text-xs text-muted-foreground">
              From upload to approval
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card data-testid="quick-actions">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {quickActions.map((action, index) => (
              <Card key={index} className="hover-elevate" data-testid={`quick-action-${index}`}>
                <CardContent className="p-6">
                  <Link href={action.href} className="block">
                    <div className="flex items-center gap-4">
                      <div className={`p-3 rounded-lg ${action.color}`}>
                        <action.icon className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-medium">{action.title}</h3>
                        <p className="text-sm text-muted-foreground">{action.description}</p>
                      </div>
                    </div>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Documents */}
        <Card data-testid="recent-documents">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Recent Documents</CardTitle>
            <Button variant="outline" size="sm" asChild data-testid="button-view-all-documents">
              <Link href="/documents">
                <Eye className="h-4 w-4 mr-2" />
                View All
              </Link>
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockRecentDocuments.map((doc) => (
                <div key={doc.id} className="flex items-center justify-between p-3 border rounded-lg hover-elevate" data-testid={`recent-doc-${doc.id}`}>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{doc.vendorName}</p>
                    <p className="text-sm text-muted-foreground">
                      {doc.invoiceNumber} • {format(doc.uploadedAt, "MMM dd")}
                    </p>
                    <p className="text-xs text-muted-foreground">by {doc.uploadedBy}</p>
                  </div>
                  <div className="ml-4">
                    {getStatusBadge(doc.status)}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Top Vendors */}
        <Card data-testid="top-vendors">
          <CardHeader>
            <CardTitle>Top Vendors by Volume</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockTopVendors.map((vendor, index) => (
                <div key={vendor.name} className="flex items-center justify-between" data-testid={`top-vendor-${index}`}>
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-8 h-8 bg-primary/10 rounded-full text-sm font-medium">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium">{vendor.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {vendor.documentCount} documents
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">${vendor.totalAmount.toLocaleString()}</p>
                    <p className="text-xs text-muted-foreground">Total amount</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}