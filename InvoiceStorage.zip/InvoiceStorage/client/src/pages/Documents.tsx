import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { DocumentCard } from "@/components/DocumentCard";
import { DocumentViewer } from "@/components/DocumentViewer";
import { DocumentFilters } from "@/components/DocumentFilters";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  Grid3X3, 
  List, 
  SortAsc, 
  SortDesc,
  Download,
  Plus
} from "lucide-react";
import { Link } from "wouter";
import { format, subDays, subWeeks, subMonths } from "date-fns";

export default function Documents() {
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const [selectedDocument, setSelectedDocument] = useState<any>(null);
  const [isViewerOpen, setIsViewerOpen] = useState(false);

  // Document filters state
  const [filters, setFilters] = useState({
    searchTerm: "",
    vendor: "all",
    category: "all",
    uploadedBy: "all",
    dateFrom: "",
    dateTo: "",
    sortBy: "createdAt" as const,
    sortOrder: "desc" as "asc" | "desc",
    limit: 50,
    offset: 0
  });

  // Build query parameters from filters
  const buildQueryParams = () => {
    const params = new URLSearchParams();
    if (filters.searchTerm) params.append('searchTerm', filters.searchTerm);
    if (filters.vendor !== 'all') params.append('vendorName', filters.vendor);
    if (filters.category !== 'all') params.append('category', filters.category);
    if (filters.uploadedBy !== 'all') params.append('uploadedBy', filters.uploadedBy);
    if (filters.dateFrom) params.append('dateFrom', filters.dateFrom);
    if (filters.dateTo) params.append('dateTo', filters.dateTo);
    params.append('sortBy', filters.sortBy);
    params.append('sortOrder', filters.sortOrder);
    params.append('limit', filters.limit.toString());
    params.append('offset', filters.offset.toString());
    return params.toString();
  };

  // Fetch documents from API
  const { data: documentsResponse, isLoading, error, refetch } = useQuery({
    queryKey: ['/api/documents', filters],
    queryFn: async () => {
      const response = await fetch(`/api/documents?${buildQueryParams()}`);
      if (!response.ok) {
        throw new Error('Failed to fetch documents');
      }
      return response.json();
    },
    staleTime: 30000, // 30 seconds
  });

  const documents = documentsResponse?.documents || [];
  const totalDocuments = documentsResponse?.total || 0;

  const handleFiltersChange = (newFilters: any) => {
    console.log('Applying filters:', newFilters);
    setFilters(prev => ({ ...prev, ...newFilters, offset: 0 }));
  };

  const handleViewDocument = (document: any) => {
    console.log('Viewing document:', document.fileName);
    setSelectedDocument(document);
    setIsViewerOpen(true);
  };

  const handleEditDocument = (document: any) => {
    console.log('Editing document:', document.fileName);
    // In a real app, this would open an edit modal or navigate to edit page
  };

  const handleDeleteDocument = (document: any) => {
    console.log('Deleting document:', document.fileName);
    // In a real app, this would show a confirmation dialog and delete the document
  };

  const handleDownloadDocument = (document: any) => {
    console.log('Downloading document:', document.fileName);
    // In a real app, this would trigger a file download
  };

  const toggleSortOrder = () => {
    const newOrder = sortOrder === "asc" ? "desc" : "asc";
    setSortOrder(newOrder);
    console.log('Sort order changed to:', newOrder);
    setFilters(prev => ({ ...prev, sortOrder: newOrder }));
  };

  const totalAmount = documents.reduce((sum: number, doc: any) => sum + (parseFloat(doc.amount) || 0), 0);

  return (
    <div className="space-y-6" data-testid="page-documents">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" asChild data-testid="button-back-dashboard">
          <Link href="/">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Documents</h1>
          <p className="text-muted-foreground">
            Manage and organize your uploaded documents
          </p>
        </div>
        <Button asChild data-testid="button-upload-new">
          <Link href="/upload">
            <Plus className="h-4 w-4 mr-2" />
            Upload New
          </Link>
        </Button>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card data-testid="summary-total-docs">
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{totalDocuments}</div>
            <p className="text-sm text-muted-foreground">Total Documents</p>
          </CardContent>
        </Card>
        
        <Card data-testid="summary-total-amount">
          <CardContent className="p-4">
            <div className="text-2xl font-bold">${totalAmount.toLocaleString()}</div>
            <p className="text-sm text-muted-foreground">Total Amount</p>
          </CardContent>
        </Card>
        
        <Card data-testid="summary-avg-amount">
          <CardContent className="p-4">
            <div className="text-2xl font-bold">
              ${totalDocuments > 0 ? (totalAmount / totalDocuments).toFixed(0) : '0'}
            </div>
            <p className="text-sm text-muted-foreground">Average Amount</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Filters Sidebar */}
        <div className="lg:col-span-1">
          <DocumentFilters onFiltersChange={handleFiltersChange} />
        </div>

        {/* Documents List */}
        <div className="lg:col-span-3 space-y-4">
          {/* Toolbar */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Badge variant="secondary" data-testid="badge-result-count">
                    {documents.length} documents
                  </Badge>
                  
                  <div className="flex items-center gap-1">
                    <Button
                      variant={viewMode === "grid" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => {
                        setViewMode("grid");
                        console.log('View mode changed to grid');
                      }}
                      data-testid="button-view-grid"
                    >
                      <Grid3X3 className="h-4 w-4" />
                    </Button>
                    <Button
                      variant={viewMode === "list" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => {
                        setViewMode("list");
                        console.log('View mode changed to list');
                      }}
                      data-testid="button-view-list"
                    >
                      <List className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={toggleSortOrder}
                    data-testid="button-sort-toggle"
                  >
                    {sortOrder === "desc" ? (
                      <SortDesc className="h-4 w-4 mr-1" />
                    ) : (
                      <SortAsc className="h-4 w-4 mr-1" />
                    )}
                    Sort by Date
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => console.log('Bulk download triggered')}
                    data-testid="button-bulk-download"
                  >
                    <Download className="h-4 w-4 mr-1" />
                    Export
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Documents Grid/List */}
          {isLoading ? (
            <Card data-testid="loading-message">
              <CardContent className="p-12 text-center">
                <div className="text-muted-foreground">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-current mx-auto mb-2" />
                  <p>Loading documents...</p>
                </div>
              </CardContent>
            </Card>
          ) : error ? (
            <Card data-testid="error-message">
              <CardContent className="p-12 text-center">
                <div className="text-destructive">
                  <h3 className="text-lg font-medium mb-2">Error loading documents</h3>
                  <p className="mb-4">{error.message}</p>
                  <Button onClick={() => refetch()}>Try Again</Button>
                </div>
              </CardContent>
            </Card>
          ) : documents.length > 0 ? (
            <div className={
              viewMode === "grid" 
                ? "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4" 
                : "space-y-4"
            } data-testid="documents-container">
              {documents.map((document: any) => (
                <DocumentCard
                  key={document.id}
                  document={document}
                  onView={handleViewDocument}
                  onEdit={handleEditDocument}
                  onDelete={handleDeleteDocument}
                  onDownload={handleDownloadDocument}
                />
              ))}
            </div>
          ) : (
            <Card data-testid="no-documents-message">
              <CardContent className="p-12 text-center">
                <div className="text-muted-foreground">
                  <h3 className="text-lg font-medium mb-2">No documents found</h3>
                  <p className="mb-4">Try adjusting your filters or upload some documents.</p>
                  <Button asChild>
                    <Link href="/upload">
                      <Plus className="h-4 w-4 mr-2" />
                      Upload Documents
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Document Viewer Modal */}
      <DocumentViewer
        document={selectedDocument}
        isOpen={isViewerOpen}
        onClose={() => {
          setIsViewerOpen(false);
          setSelectedDocument(null);
        }}
        onEdit={handleEditDocument}
        onDelete={handleDeleteDocument}
        onDownload={handleDownloadDocument}
      />
    </div>
  );
}