# replit.md

## Overview

This is a Document Management System designed for secure invoice storage and organization. The system enables users to upload scanned invoices with drag-and-drop functionality, automatically organize them using vendor names and invoice numbers, and provide comprehensive search and reporting capabilities. The application features role-based permissions, multi-user support with activity tracking, and date-wise reporting with export functionality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design system following Material Design principles
- **State Management**: TanStack React Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Theme System**: Custom light/dark theme provider with CSS variables

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Database ORM**: Drizzle ORM for type-safe database operations
- **File Uploads**: Multer middleware for handling multipart form data
- **Session Management**: Express sessions with PostgreSQL session store

### Authentication System
- **Provider**: Replit Auth with OpenID Connect integration
- **Session Storage**: PostgreSQL-backed sessions with connect-pg-simple
- **Authorization**: Role-based access control (user/admin roles)

### Database Schema
- **Users Table**: Stores user profiles from Replit Auth (id, email, firstName, lastName, profileImageUrl, role)
- **Documents Table**: Core document storage with metadata (fileName, vendorName, invoiceNumber, invoiceDate, amount, category, uploadedBy)
- **Document Permissions**: Fine-grained access control for document viewing/editing
- **Sessions Table**: Required for Replit Auth session persistence

### File Storage
- **Upload Directory**: Local filesystem storage in `/uploads` directory
- **File Types**: Supports PDF, JPEG, PNG, and TIFF formats
- **Size Limits**: 10MB maximum file size per upload
- **Naming Convention**: Automatic file naming using vendor names and invoice numbers

### Component Design System
- **Typography**: Inter font family from Google Fonts
- **Color Palette**: Custom HSL-based color system with light/dark mode variants
- **Layout**: Sidebar navigation with collapsible sections
- **Form Components**: Material Design-inspired input fields with floating labels
- **Upload Interface**: Drag-and-drop zone with visual feedback

### Data Flow Architecture
- **Client-Server Communication**: REST API with JSON responses
- **Error Handling**: Centralized error boundaries with user-friendly messages
- **Loading States**: Comprehensive loading indicators throughout the application
- **Optimistic Updates**: Immediate UI feedback with server synchronization

## External Dependencies

### Core Infrastructure
- **Database**: Neon PostgreSQL serverless database
- **Authentication**: Replit Auth service for user management
- **Session Storage**: PostgreSQL session store for persistent login state

### Development Tools
- **Package Manager**: npm with lockfile for reproducible builds
- **TypeScript**: Full type safety across client and server
- **ESLint/Prettier**: Code quality and formatting tools (configured via package.json)

### Third-Party Libraries
- **UI Components**: Radix UI primitives for accessible component foundation
- **Form Handling**: React Hook Form with Zod validation
- **Date Utilities**: date-fns for date formatting and manipulation
- **File Processing**: Multer for multipart form handling
- **Query Management**: TanStack React Query for server state caching

### Build and Deployment
- **Build Tool**: Vite with React plugin and TypeScript support
- **Server Bundling**: esbuild for production server compilation
- **Development Server**: Hot module replacement with Vite dev server
- **Static Assets**: Vite handles CSS, images, and other static resources

### Runtime Environment
- **Node.js**: ES modules with TypeScript compilation
- **Environment Variables**: Database URL, session secrets, and auth configuration
- **Process Management**: Development and production startup scripts